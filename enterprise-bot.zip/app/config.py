import os

# Telegram Configuration
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "YOUR_TELEGRAM_BOT_TOKEN_HERE")
ADMIN_IDS = [123456789]  # Add your Telegram ID here

# Automation Configuration
REGISTER_URL = "https://teraboxlink.com/s/1-lVO5HBvGuwSIoEwhY-I_w"
TOTAL_ACCOUNTS = 200
HEADLESS = True

PROXIES = [
    # "http://127.0.0.1:8080",
]

OUTPUT_FILE = "data/accounts.csv"
LOG_FILE = "logs/system.log"
