import os
import pandas as pd
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters
from app.config import TELEGRAM_TOKEN, OUTPUT_FILE, LOG_FILE
from app.services.registration_service import run_automation
import threading

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [['🚀 Start Automation', '📊 Status'], ['📁 Download CSV', '📜 View Logs']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(
        "Welcome to Enterprise Automation Bot!\nChoose an option:",
        reply_markup=reply_markup
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text == '🚀 Start Automation':
        await update.message.reply_text("Starting automation process for 10 accounts... (Check status in a moment)")
        # Run in a separate thread to not block the bot
        threading.Thread(target=run_automation, args=(10,)).start()
        
    elif text == '📊 Status':
        if os.path.exists(OUTPUT_FILE):
            df = pd.read_csv(OUTPUT_FILE)
            count = len(df)
            await update.message.reply_text(f"Total accounts created so far: {count}")
        else:
            await update.message.reply_text("No accounts created yet.")

    elif text == '📁 Download CSV':
        if os.path.exists(OUTPUT_FILE):
            await update.message.reply_document(document=open(OUTPUT_FILE, 'rb'), filename="accounts.csv")
        else:
            await update.message.reply_text("CSV file not found.")

    elif text == '📜 View Logs':
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r') as f:
                last_logs = "".join(f.readlines()[-10:])
            await update.message.reply_text(f"Last 10 log entries:\n\n{last_logs}")
        else:
            await update.message.reply_text("Log file not found.")

def run_bot():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))
    
    print("Bot is running...")
    app.run_polling()
