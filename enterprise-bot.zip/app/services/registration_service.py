import os
import pandas as pd
from multiprocessing import Pool, Manager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from app.core.driver_factory import create_driver
from app.core.account_generator import generate_account
from app.core.logger import setup_logger
from app.config import REGISTER_URL, HEADLESS, OUTPUT_FILE

logger = setup_logger()

def worker(args):
    index, shared_list = args
    driver = create_driver(headless=HEADLESS)
    wait = WebDriverWait(driver, 10)

    try:
        driver.get(REGISTER_URL)
        account = generate_account()

        # Wait for elements (Adjust IDs based on actual site)
        wait.until(EC.presence_of_element_located((By.ID, "username")))

        driver.find_element(By.ID, "username").send_keys(account["username"])
        driver.find_element(By.ID, "email").send_keys(account["email"])
        driver.find_element(By.ID, "password").send_keys(account["password"])

        driver.find_element(By.XPATH, "//button[@type='submit']").click()

        logger.info(f"Created account: {account['email']}")
        shared_list.append(account)
        return account

    except Exception as e:
        logger.error(f"Error in worker {index}: {str(e)}")
        return None

    finally:
        driver.quit()

def run_automation(count=10):
    os.makedirs("data", exist_ok=True)
    
    manager = Manager()
    shared_list = manager.list()
    
    with Pool(processes=3) as pool:
        pool.map(worker, [(i, shared_list) for i in range(count)])

    results = list(shared_list)
    if results:
        df = pd.DataFrame(results)
        # Append if exists, else create
        if os.path.exists(OUTPUT_FILE):
            df.to_csv(OUTPUT_FILE, mode='a', header=False, index=False)
        else:
            df.to_csv(OUTPUT_FILE, index=False)

    logger.info(f"Finished creating {len(results)} accounts")
    return len(results)
