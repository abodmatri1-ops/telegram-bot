from faker import Faker

fake = Faker()

def generate_account():
    return {
        "username": fake.user_name(),
        "email": fake.unique.email(),
        "password": fake.password(length=10)
    }
