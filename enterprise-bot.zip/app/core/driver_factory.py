from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def create_driver(proxy=None, headless=True):
    options = Options()

    if headless:
        options.add_argument("--headless=new")

    options.add_argument("--start-maximized")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    if proxy:
        options.add_argument(f'--proxy-server={proxy}')

    return webdriver.Chrome(options=options)
